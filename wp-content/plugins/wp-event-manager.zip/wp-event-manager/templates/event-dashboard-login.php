<div id="event-manager-event-dashboard">
	<p class="account-sign-in wpem-alert wpem-alert-info"><?php _e( 'You need to be signed in to manage your listings.', 'wp-event-manager' ); ?> <a href="<?php echo apply_filters( 'event_manager_event_dashboard_login_url', esc_url(get_option('event_manager_login_page_url'),esc_url(wp_login_url())) ); ?>"><?php _e( 'Sign in', 'wp-event-manager' ); ?></a></p>
</div>
