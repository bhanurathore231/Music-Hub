<?php /** Intentionally empty - override to modify the content **/ ?>
<div class="event_listings_class">
	<div class="no_event_listings_found_widget wpem-alert wpem-alert-danger wpem-mb-0"><?php _e( 'There are currently no events.', 'wp-event-manager' ); ?></div>
</div>
